// $(document).ready(function(){
//     $('head').load('./components/head.html');
//     $('#header').load('./components/header/header.html');
//     $('#slider').load('./components/slider/slider.html');
//     $('#popup').load('./components/popup/popup.html');
// })